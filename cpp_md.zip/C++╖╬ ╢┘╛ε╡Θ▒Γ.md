# C++로 뛰어들기

#### 코드 구조
```cpp
#include <iostream> 

using namespace std; // header file이 제공하는 루틴들을 더 짧은 형태로 사용할 수 있게 해줌.

int main ()
{
	cout << "HEY, you, I'm alive! Oh, and Hello World!\n";
	cin.get();
}
```


```
#include <iostream>
```
- 'iostream'이라는 일종의 header file의 코드르 프로그램에 넣고나서 실행 파일을 만들라고 컴파일러에 주문하는 include문.

```
using namespace std; 
```
- header file이 제공하는 루틴들을 더 짧은 형태로 사용할 수 있게 해줌.

```
int main () 
```
- 정수를 리턴하는 함수를 생성

```
cout << "HEY, you, I'm alive! Oh, and Hello World!\n";
cin.get();
```


#### type, cin, cout, endl
```cpp
#include <iostream>

using namespace std;

int main ()
{
    int first_argument;
    int second_argument;
    cout << "Enter first argument: ";
    cin >> first_argument;
    cout << "Enter second argument: ";
    cin >> second_argument;
    cout << first_argument << " * " << second_argument
         << " == " << first_argument * second_argument
         << endl;
    cout << first_argument << " + " << second_argument
         << " == " << first_argument + second_argument
         << endl;
    cout << first_argument << " / " << second_argument
         << " == " << first_argument / second_argument
         << endl;
    cout << first_argument << " - " << second_argument
         << " == " << first_argument - second_argument
         << endl;
}
```
```
int first_argument;
```
- 정수(int) 타입의 변수 선언
- int 외에도 string, float, double, char 등이 있음.

```
cout << "Enter first argument: ";
cin >> first_argument;
```
- cout: "Enter first argument: "를 출력
- cin: 입력값을 받아서 first_argument변수에 저장

```
cout << "Hello\n"
cout << "Hello" << endl
```
- endl: 줄바꿈 (\n 문자열을 이용하기도 함.)


#### 연산자
```
x = 5;
x++;
a == 5;
x += 5;
x -= 5;
x *= 5;
x /= 5;
```
- x++: x = x + 1
- x += 5 : x = x + 5

```
int x = 0;
cout << x++;
```
- 0을 출력. x가 수정되었지만 x++라는 수식은 x의 원래 값을 리턴하기 때문.

```
int x = 0;
cout << ++x;
```
- 1을 출력. x에 1을 더한 뒤 x의 값을 가져오기 때문.

```
string user_full_name = "Hong" + " " + "gildong";
```
- 문자열 붙이기

#### If문
```cpp
#include <iostream>

using namespace std;

int main()
{
	int num;
	cout << "Enter a number: ";
	cin >> num;
	if ( num < 0 ) 
	{
		cout << "You entered a negative number\n";
	}
	else if ( num == 0 )
	{
		cout << "You entered zero\n";
	}
	else
	{
		cout << "You entered a positive number\n";
	}
}

```

#### Boolean 연산자
```
if ( ! (x == 2 && x == 3) )
if (x == 2 || x == 3)
```
- !: not
- &&: and
- ||: or


#### Loop
```cpp
#include <iostream>

using namespace std; 

int main ()
{
	// The loop goes while x < 10, and x increases by one every loop
	for ( int x = 0; x < 10; x++ ) 
	{
		// Keep in mind that the loop condition checks 
		// the conditional statement before it loops again.
		// consequently, when x equals 10 the loop breaks.
		// x is updated before the condition is checked.    
		cout<< x << " squared is " << x * x << endl;
	}
}
```
- for ( 변수 초기화; 조건; 변수 업데이트 )

```cpp
#include <string>
#include <iostream>

using namespace std;

int main ()
#include <string>
#include <iostream>

using namespace std;
 
int main ()
{
	string password;
	while ( 1 )
	{
		cout << "Please enter your password: ";
		cin >> password;
		if ( password == "foobar" )
		{
			break;
		}
	}
	cout << "Welcome, you got the password right";
}
```
- while ( 조건 ) 
- if ( 조건 ) { break; }: 특정 조건에서 loop를 탈출.
- if ( 조건 ) { continue; }: 특정 조건에서 loop를 건너뜀.

```cpp
#include <string>
#include <iostream>

using namespace std;

int main ()
{
	string password;
	do
	{
		cout << "Please enter your password: ";
		cin >> password;
	} while ( password != "foobar" );
	cout << "Welcome, you got the password right";
}
```
- do { 실행 } while ( 조건 ): 실행 후 조건을 충족하지 않는 경우 충족할때까지 다시 실행.


#### 함수
```cpp
#include <iostream>   // needed for cout

using namespace std;

int add (int x, int y)
{
	return x + y;
} 

int main ()
{
	int result = add( 1, 2 );  // call add and assign the result to a variable
	cout << "The result is: " << result << '\n';
	cout << "Adding 3 and 4 gives us: " << add( 3, 4 );
}
```
- int add (int x, int y): 정수 x와 정수 y를 받아 정수를 출력하는 함수를 만든다.

```cpp

```



